#! /usr/bin/python3
# Definimos la clase padre
class Miembro():
	# Definimos que parametros acepta el objeto "Miembro"
	def __init__(self, nombre, direccion, dni):
		self.nombre = nombre
		self.direccion = direccion
		self.dni = dni
# Definimos la clase hija "Profesor" que hereda de "Miembro"
class Profesor(Miembro):
	# Sobrecargamos el constructor de la super clase
	def __init__(self, nombre, direccion, dni, numRegistro):
		Miembro.__init__(self, nombre, direccion, dni)
		self.numRegistro = numRegistro
		self.asignatura = []
	# Definimos el metodo añadir asignatura que añade otro atributo al objeto
	def añadirAsignatura(self, object):
		self.asignatura.append(object.nombre)
		self.codigo = object.codigo
# Definimos la clase hija "Estudiante" que hereda de "Miembro"
class Estudiante(Miembro):
	# Sobrecargamos el constructor de la super clase
	def __init__(self, nombre, direccion, dni, numEstudiante):
		Miembro.__init__(self, nombre, direccion, dni)
		self.numEstudiante = numEstudiante
		self.asignatura = []
	# Definimos el metodo añadir profesor
	def añadirProfesor(self, object):
		self.profesor = object.nombre
		self.asignatura.append(object.asignatura)
# Definimos la clase asignatura asignatura 
class Asignatura:
	# Creamos el constructor
	def __init__(self, nombre, codigo):
		self.nombre = nombre
		self.codigo = codigo
# instanciamos los objetos
Luis = Profesor("Luis", 50, 34567, 5001)
Luisito = Estudiante("Luisito", 20, 56678, 1001)
matematicas = Asignatura("Matematicas", 5)
algebra = Asignatura("Álgebra", 7)
print("Profesores: ")
print("Nombre: " + str(Luis.nombre) + ". Dirección: " + str(Luis.direccion) + ". DNI: " + str(Luis.dni) + ". Núm. registro: " + str(Luis.numRegistro))
print("Estudiante: ")
print("Nombre: " + Luisito.nombre + ". Dirección: " + str(Luisito.direccion) + ". DNI: " + str(Luisito.dni) + ". Núm. estudiante: " + str(Luisito.numEstudiante))
print("Asignaturas: ")
print("Nombre: " + matematicas.nombre + ". Código: " + str(matematicas.codigo))
print("Nombre: " + algebra.nombre + ". Codigo: " + str(algebra.codigo))
Luis.añadirAsignatura(matematicas)
Luis.añadirAsignatura(algebra)
Luisito.añadirProfesor(Luis)
print()
print(Luisito.nombre + " tiene la asignatura " + str(Luisito.asignatura) + " con el profesor " + str(Luisito.profesor))






