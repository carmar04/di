#! /usr/bin/python3
var1 = input()
var2 = input()
def comparador(var1, var2):
	if var1.isdigit() and var2.isdigit():
		if var1 > var2:
			print("Grande Unga Unga")
		if var1 == var2:
			print("Igual")
		if var1 < var2:
			print("Mas pequeño")
	else:
		print("Cadena encontrada")
comparador(var1, var2)
