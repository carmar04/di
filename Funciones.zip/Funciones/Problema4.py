#! /usr/bin/python3
string = input()
def isVowel(char):
	vocal = 0
	for c in char:
		if c in "aeiouAEIOU":
			vocal = vocal + 1
	print("Número de vocales: " + str(vocal))
isVowel(string)
