#! /usr/bin/python3
string = input()
def isVowel(char):
	checker = False
	if len(char) > 1:
		print("Debe introducir solo un caracter, ha introducido " + str(len(char)) + " caracteres")
	else:
		if char == 'a' or char == 'e' or char == 'i' or char =='o' or char == 'u' or char == 'A' or char == 'E' or char == 'I' or char =='O' or char == 'U':
			checker = True
	if checker == True:
		return True
	else:
		return False
isVowel(string)
